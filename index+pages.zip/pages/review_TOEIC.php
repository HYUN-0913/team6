﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>REreview</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="../layout/styles/layout.css" type="text/css" />
</head>
<body id="top">
<div class="wrapper col1">
  <div id="head">
    <h1><a href="../index.html">REreview</a></h1>
    <p>인터넷강의 리뷰 모음</p>
    <div id="topnav">
      <ul>
        <li><a href="../index.html">홈/로그인</a></li>
        <li><a href="style-demo.html">회원가입</a></li>
        <li><a href="#">리뷰작성</a>
          <ul>
            <li><a href="full-width_TOEIC.html">TOEIC</a></li>
            <li><a href="full-width_TOEFL.html">TOEFL</a></li>
            <li><a href="full-width_TEPS.html">TEPS</a></li>
          </ul>
        </li>
        <li><a class="active" href="#">리뷰보기</a>
          <ul>
            <li><a href="review_TOEIC.php">TOEIC</a></li>
            <li><a href="review_TOEFL.php">TOEFL</a></li>
            <li><a href="review_TEPS.php">TEPS</a></li>
          </ul>
        </li>
      </ul>
    </div>
    <div id="search">
      <form action="#" method="post">
        <fieldset>
          <legend>Site Search</legend>
          <input type="submit" name="go" id="go" value="GO" />
          <input type="text" value="Search"  onfocus="this.value=(this.value=='Search the site&hellip;')? '' : this.value ;" />
        </fieldset>
      </form>
    </div>
  </div>
</div>

</div>

<div class="wrapper col2">
  <div id="gallery">
    <p class="imgholder"><img src="https://inmun360.culture.go.kr/upload/board/image/82/2358882_201810221330020970.jpg" width=960 height=380 /></p>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">


  <h2>리뷰 보기-TOEIC</h2>
  <?php
    @$db = new mysqli('localhost', 'rereview', 'Team6', 'lecture');

   if (mysqli_connect_errno()) {

      echo "<p>Error: Could not connect to database.<br />
   
      Please try again later.</p>";

      exit;
   }

   $result = $db -> query("SELECT ReviewNo, Title, Subject, LectureNo, Star, Review FROM Review WHERE Subject='TOEIC'");

    echo "<table border='1'> <tr> <th>강좌번호</th> <th>제목</th> <th>점수</th> </tr>";

    if($result->num_rows > 0){
         while($row = $result->fetch_assoc()) {
            //echo $row;
            echo "<tr><td>". $row["LectureNo"] ."</td><td>". $row["Title"] ."</td><td>".$row["Star"] ."</td></tr>";
        }
    }
    else{
      echo "0 result";
    }

      echo "</table>"; 
    echo "</div>";

    $db->close();
  ?>    
  </div>
</div>



<div class="wrapper col5">
  <div id="footer">
  

<div id="contactform">
      <h2>REreview에 오신것을 환영합니다.</h2>
      <form action="#" method="post">
       <p> 국어 </p>
    <p> 영어 </p>
    <p> 수학 </p>
 <p> 기타 </p>
<br> <p>다양한 과목, 시험에 대한 강의리뷰 서비스를 제공합니다.</p>
      </form>
    </div>




    <!-- End Contact Form -->
    <div id="compdetails">
      <div id="officialdetails">
        <h2>Company Information !</h2>
        <ul>
          <li>Company Name REreview</li>
          <li>Registered in Korea; jaejae </li>
          <li>Company No. xxxxxxx</li>
          <li class="last">VAT No. xxxxxxxxx</li>
        </ul>
        <h2>News</h2>
        <p>News papper| SNS</p>
      </div>
      <div id="contactdetails">
        <h2>Our Contact Details !</h2>
        <ul>
          <li>Company Name</li>
          <li>Street Name </li>
          <li>Town</li>
          <li>Postcode</li>
          <li>Tel: xxxxx xxxxxxxxxx</li>
          <li>Fax: xxxxx xxxxxxxxxx</li>
          <li>Email: xxxx@xxxxxx.com</li>
          
        </ul>
      </div>
      <div class="clear"></div>
    </div>
    <!-- End Company Details -->
    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2019 - REreview- </p>
    
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>