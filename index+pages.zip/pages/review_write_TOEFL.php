<!DOCTYPE html>

<html>

<head>

</head>

<body>

   <?php

   if (
      !isset($_POST['title']) || !isset($_POST['lecture_name'])
      || !isset($_POST['teacher']) || !isset($_POST['score']) || !isset($_POST['comment'])
   ) {

      echo "<p>You have not entered all the required details.<br />
   
      Please go back and try again.</p>";

      exit;
   }

   // create short variable names

   $title = $_POST['title'];

   $lecture_name = $_POST['lecture_name'];

   $teacher = $_POST['teacher'];

   $score = $_POST['score'];

   $score = doubleval($score);

   $comment = $_POST['comment'];

   @$db = new mysqli('localhost', 'rereview', 'Team6', 'lecture');


   if (mysqli_connect_errno()) {

      echo "<p>Error: Could not connect to database.<br />
   
      Please try again later.</p>";

      exit;
   }

   $query = "SELECT LectureNo FROM lectures WHERE Teacher=? and LectureName=?";

   $stmt = $db->prepare($query);

   $stmt->bind_param('ss', $teacher, $lecture_name);

   $stmt->execute();

   $stmt->store_result();

   $stmt->bind_result($lectureNo);

   while($stmt->fetch()){}

   $query = "INSERT INTO review VALUES (null, ? , 'TOEFL', ?, ?, ?)";

   $stmt = $db->prepare($query);

   $stmt->bind_param('sdds', $title, $lectureNo, $score, $comment);

   $stmt->execute();

   while($stmt->fetch()){}

   if ($stmt->affected_rows > 0) {

      echo "<p>리뷰가 작성되었습니다.</p>";
   }
   else {

      echo "<p>An error has occurred.<br />
   
      리뷰가 작성되지 않았습니다.</p>";
   }


   $db->close();


   ?>

</body>

</html>