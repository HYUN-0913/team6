﻿<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html lang="ko">
<head>
<title>REreview</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" href="layout/styles/layout.css" type="text/css" />
</head>
<body id="top">
<div class="wrapper col1">
  <div id="head">
    <h1><a href="index.php">REreview</a></h1>
    <p>인터넷강의 리뷰 모음</p>
    <div id="topnav">
      <ul>
        <li><a class="active" href="index.html">홈/로그인</a></li>
        <li><a href="pages/style_demo.html">회원가입</a></li>
        <li><a href="#">리뷰작성</a>
          <ul>
            <li><a href="pages/full-width_TOEIC.html">TOEIC</a></li>
            <li><a href="pages/full-width_TOEFL.html">TOEFL</a></li>
            <li><a href="pages/full-width_TEPS.html">TEPS</a></li>
          </ul>
        </li>
        <li><a href="#">리뷰보기</a>
          <ul>
            <li><a href="pages/review_TOEIC.php">TOEIC</a></li>
            <li><a href="pages/review_TOEFL.php">TOEFL</a></li>
            <li><a href="pages/review_TEPS.php">TEPS</a></li>
          </ul>
        </li>
        <li class="last"> </li>
      </ul>
    </div>
    <div id="search">
      <form action="#" method="post">
        <fieldset>
          <legend>Site Search</legend>
          <input type="submit" name="go" id="go" value="GO" />
          <input type="text" value="Search"  onfocus="this.value=(this.value=='Search the site&hellip;')? '' : this.value ;" />
        </fieldset>
      </form>
    </div>
  </div>
</div>
<div class="wrapper col2">
  <div id="gallery">
    <p class="imgholder"><img src="https://ak1.picdn.net/shutterstock/videos/17616601/thumb/1.jpg" width=960 height=380 /></p>
    <div class="clear"></div>
  </div>
</div>
<div class="wrapper col4">
  <div id="container">
    <div id="content">
      <h1>우리는 REreview입니다.</h1>
      <p>REreview란 인터넷강의 리뷰 모음 웹앱입니다.</p>
<p> </p>
      <p>수많은 인터넷강의 사이트와 강의들이 있습니다.</p>
      <p>하지만 당신은 어떤 강의를 들어야할까요?</p>
<p>우리  REreview는 리뷰(review)를 다시(RE) 살펴보게 해줍니다.</p>
<p>당신의 선택을 도와드리겠습니다.</p>
     
      <div class="homecontent">
        <ul>
          <li>
            <p class="imgholder"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR1UWNYtqokM6MUfG_CGBGAKs_33bHm0vnUju5Owku5zgAYvfd4&s" width=286 height=100/></p>
            <h2>Mission & Vision</h2>
            <p>수많은 인터넷강의에 대한 리뷰를 체계적으로 제공하여 당신의 목표를 향한 지름길을 보여드리고 당신의 선택을 도와드리는 것이 저희 REreivew의  미션이자 비전입니다.</p>

       
          </li>
          <li class="last">
            <p class="imgholder"><img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRyT9R9EVa2hvhTWUt4feY32QGsgCApprHovS0ZI0gv7nrTo2nF&s" width=286 height=100/ /></p>
            <h2>Extended Learning <br>in Korean, English and Math</h2>
            <p>인터넷강의 이용의 단점은 최소화하고 장점을 최대화하도록 도움을 드립니다.</p>
         </li>
        </ul>
        <div class="clear"></div>
      </div>
      <p>어떤 사이트에서, 어떤 강사의, 어떤 강의를 수강해야할지 모르시겠다고요? 우리  REreview와 함께하면 이런 고민들이 해결됩니다. 참여를 원하신다면 간단한 회원가입 후, 로그인 해주시면 바로 참여하실 수 있습니다. 인터넷가의 리뷰에 대한 다양한 좋은 서비스들이 제공됩니다. Rereview와 함께해요!</p>
    </p>
 </div>

 <div id="column">
      <div id="featured">
        <ul>
          <li>
            <h2>로그인</h2>

       
<div id="contactform">
  <div id="contactform">
  <?php
  session_start();
      if(!isset($_SESSION['user_id'])){
        echo "<p>로그인을 해 주세요 <a href=\"login.php\">[로그인]</a></p>";
    } 
    else {
      $user_id = $_SESSION['user_id'];
      echo "<p><strong>$user_id</strong>님 환영합니다.";
      echo "<a href=\"logout.php\">[로그아웃]</a></p>";
    }
  ?>

    </div>

    </div>
    <div id="column">
      <div id="featured">
        <ul>
          
        </ul>
      </div>
    
    </div>
    <div class="clear"></div>
  </div>
</div>


       

          </li>
        </ul>
      
    </div>
    <div class="clear"></div>
  </div>
</div>











<div class="wrapper col4">
  <div id="container">

      <h1>실시간 리뷰</h1>
  <table summary="Summary Here" cellpadding="0" cellspacing="0">
        <thead>
          <tr>
            <th>Header 1</th>
            <th>Header 2</th>
            <th>Header 3</th>
            <th>Header 4</th>
          </tr>
        </thead>
        <tbody>
          <tr class="light">
            <td>Value 1</td>
            <td>Value 2</td>
            <td>Value 3</td>
            <td>Value 4</td>
          </tr>
          <tr class="dark">
            <td>Value 5</td>
            <td>Value 6</td>
            <td>Value 7</td>
            <td>Value 8</td>
          </tr>
          <tr class="light">
            <td>Value 9</td>
            <td>Value 10</td>
            <td>Value 11</td>
            <td>Value 12</td>
          </tr>
          <tr class="dark">
            <td>Value 13</td>
            <td>Value 14</td>
            <td>Value 15</td>
            <td>Value 16</td>
          </tr>
<tr class="light">
            <td>Value 17</td>
            <td>Value 18</td>
            <td>Value 19</td>
            <td>Value 20</td>
          </tr>
<tr class="dark">
            <td>Value 21</td>
            <td>Value 22</td>
            <td>Value 23</td>
            <td>Value 24</td>
          </tr>
<tr class="light">
            <td>Value 25</td>
            <td>Value 26</td>
            <td>Value 27</td>
            <td>Value 28</td>
          </tr>
<tr class="dark">
            <td>Value 29</td>
            <td>Value 30</td>
            <td>Value 31</td>
            <td>Value 32</td>
          </tr>
<tr class="light">
            <td>Value 33</td>
            <td>Value 34</td>
            <td>Value 35</td>
            <td>Value 36</td>
          </tr>
<tr class="dark">
            <td>Value 37</td>
            <td>Value 38</td>
            <td>Value 39</td>
            <td>Value 40</td>
          </tr>

          </tr>
        </tbody>
      </table>   

 </div> </div>
   
 </div>



<div class="wrapper col5">
  <div id="footer">
  

<div id="contactform">
      <h2>REreview에 오신것을 환영합니다.</h2>
      <form action="#" method="post">
       <p> 국어 </p>
    <p> 영어 </p>
    <p> 수학 </p>
 <p> 기타 </p>
<br> <p>다양한 과목, 시험에 대한 강의리뷰 서비스를 제공합니다.</p>
      </form>
    </div>




    <!-- End Contact Form -->
    <div id="compdetails">
      <div id="officialdetails">
        <h2>Company Information !</h2>
        <ul>
          <li>Company Name REreview</li>
          <li>Registered in Korea; jaejae </li>
          <li>Company No. xxxxxxx</li>
          <li class="last">VAT No. xxxxxxxxx</li>
        </ul>
        <h2>News</h2>
        <p>News papper| SNS</p>
      </div>
      <div id="contactdetails">
        <h2>Our Contact Details !</h2>
        <ul>
          <li>Company Name</li>
          <li>Street Name </li>
          <li>Town</li>
          <li>Postcode</li>
          <li>Tel: xxxxx xxxxxxxxxx</li>
          <li>Fax: xxxxx xxxxxxxxxx</li>
          <li>Email: xxxx@xxxxxx.com</li>
          
        </ul>
      </div>
      <div class="clear"></div>
    </div>
    <!-- End Company Details -->
    <div id="copyright">
      <p class="fl_left">Copyright &copy; 2019 - REreview- </p>
    
      <br class="clear" />
    </div>
    <div class="clear"></div>
  </div>
</div>
</body>
</html>