<html>
<head>
  <title> login </title>
  <link rel="stylesheet" href="layout/styles/logincss.css">
</head>

<body>

  <div class="wrapper col1">
   <div id="head">
    <h1><a href="index.php">REreview</a></h1>
    <p>인터넷강의 리뷰 모음</p>
    <div id="topnav">
      <ul>
        <li><a class="active" href="index.php">홈/로그인</a></li>
        <li><a href="pages/style-demo.html">회원가입</a></li>
        <li><a href="#">리뷰작성</a>
          <ul>
            <li><a href="pages/full-width_TOEIC.html">TOEIC</a></li>
            <li><a href="pages/full-width_TOEFL.html">TOEFL</a></li>
            <li><a href="pages/full-width_TEPS.html">TEPS</a></li>
          </ul>
        </li>
        <li><a href="#">리뷰보기</a>
          <ul>
            <li><a href="pages/review_TOEIC.php">TOEIC</a></li>
            <li><a href="pages/review_TOEFL.php">TOEFL</a></li>
            <li><a href="pages/review_TEPS.php">TEPS</a></li>
          </ul>
        </li>
        <li class="last"> </li>
      </ul>
    </div>
    <div id="search">
      <form action="#" method="post">
        <fieldset>
          <legend>Site Search</legend>
          <input type="submit" name="go" id="go" value="GO" />
          <input type="text" value="Search"  onfocus="this.value=(this.value=='Search the site&hellip;')? '' : this.value ;" />
        </fieldset>
      </form>
    </div>
  </div>
</div>


<div class="login-page">
  <div class="form">
    <form action = "login_ok.php" method ="post" class="login-form">
      <input id = "user_id" name ="user_id" type="text" placeholder="username"/>
      <input id = "user_pw" name ="user_pw" type="password" placeholder="password"/>
      <button type="submit" >login</button>
      <p class="message">Not registered? <a href="pages/style_demo.html">Create an account</a></p>
    </form>
  </div>
</div>

</body>
</html>